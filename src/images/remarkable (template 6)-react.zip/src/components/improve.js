import React from 'react'

import PropTypes from 'prop-types'

import './improve.css'

const Improve = (props) => {
  return (
    <section className="improve-improve">
      <div className="improve-heading">
        <h2 className="improve-text">{props.heading}</h2>
        <p className="improve-text1">{props.text}</p>
      </div>
      <div className="improve-tabs">
        <div className="improve-switches">
          <span className="switch switch-active">{props.Switch}</span>
          <span className="switch">{props.Switch1}</span>
        </div>
        <div className="improve-content">
          <div className="improve-details">
            <div className="improve-header">
              <h2 className="improve-text2">{props.heading1}</h2>
              <div className="improve-description">
                <p className="improve-text3">{props.text1}</p>
                <p className="improve-text4">{props.text2}</p>
              </div>
            </div>
            <button className="button">
              <span className="improve-text5">
                <span>Get a quote</span>
                <br></br>
              </span>
            </button>
          </div>
          <div className="improve-image">
            <img
              alt={props.image_alt}
              src={props.image_src}
              className="improve-image1"
            />
          </div>
        </div>
      </div>
    </section>
  )
}

Improve.defaultProps = {
  heading: 'Set new heights, improve your business',
  text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.',
  Switch: 'Connect with professionals',
  Switch1: 'Connect with mentors',
  image_src:
    '/playground_assets/pexels-darina-belonogova-7959815%201-1500w.png',
  image_alt: 'image',
  heading1: 'Website Engagement Design',
  text1:
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  text2:
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ',
}

Improve.propTypes = {
  heading: PropTypes.string,
  text: PropTypes.string,
  Switch: PropTypes.string,
  Switch1: PropTypes.string,
  image_src: PropTypes.string,
  image_alt: PropTypes.string,
  heading1: PropTypes.string,
  text1: PropTypes.string,
  text2: PropTypes.string,
}

export default Improve
